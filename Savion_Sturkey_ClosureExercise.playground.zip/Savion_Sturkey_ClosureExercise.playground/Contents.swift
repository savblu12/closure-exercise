import UIKit

var str = "Hello, playground"

var calc = {(inputOne: Int, inputTwo: Int) -> Int in
    return inputOne * inputTwo
}
print(calc(3, 3))
